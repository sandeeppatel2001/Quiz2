import React from "react";
import "../styles/Categories.css";
import drag from "./drag.svg";
import Mcq from "./smallComp/Mcq";
import { useDispatch, useSelector } from "react-redux";
import { savedataaction3 } from "../store";
const Comprehension = () => {
  const dispatch = useDispatch();
  const data = useSelector((state) => state);
  const data3 = data.counter3.count2;
  const addnewform = () => {
    dispatch(savedataaction3.addnewquestion());
  };

  return (
    <div className="category__box mt-5 mb-5 ms-1">
      <div className="ms-1 mb-5">
        <div className="ms-4 mt-4 question">
          <img src={drag} className="img mb-1 me-1" />
          Question 3
        </div>
        <div className="ms-4 mt-3 mb-5">
          <textarea
            style={{ width: "500px", height: "150px", padding: "20px" }}
            type="text"
            name="name"
            className="category__text"
          />
        </div>
        <div className="ms-4 question__box">
          <div className="question__item mt-2 mb-3 ms-1">
            <div className="ms-1 pb-2">
              <div className="ms-4 mt-4 heading">
                <img src={drag} className="img mb-1 me-1" />
                Question 2.1
              </div>
              <div>
                {data3.map((v, i) => {
                  return <Mcq name={i} />;
                })}
              </div>
            </div>
          </div>
        </div>
        <button onClick={addnewform}>+</button>
      </div>
    </div>
  );
};

export default Comprehension;
