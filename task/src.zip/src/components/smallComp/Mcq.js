import Option from "./Option";
import { savedataaction3 } from "../../store";
import { useDispatch } from "react-redux";
const Mcq = (props) => {
  const dispatch = useDispatch();
  const addin2 = () => {
    dispatch(savedataaction3.addnewquestion2());
  };
  return (
    <div className="ms-4 mt-3 ">
      <h6>Please select your age:</h6>
      <div className="mb-1">
        <input type="radio" name={props.name} className="me-1" />
        <label>{<Option></Option>}</label>
      </div>
      <div className="mb-1">
        <input type="radio" name={props.name} className="me-1" />
        <label>{<Option></Option>}</label>
      </div>
      <div className="mb-1">
        <input type="radio" name={props.name} className="me-1" />
        <label>{<Option></Option>}</label>
      </div>
      <div className="mb-1">
        <input type="radio" name={props.name} className="me-1" />
        <label>{<Option></Option>}</label>
      </div>
      <button onClick={addin2}>+</button>
    </div>
  );
};

export default Mcq;
