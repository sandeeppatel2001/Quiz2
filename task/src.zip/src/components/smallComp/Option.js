
const Option = () => {
  return (
    <div>
      <div className="option">
        <div>
          <input
            placeholder="Type Your Options Here"
            style={{ width: "300px" }}
          ></input>
        </div>
      </div>
    </div>
  );
};
export default Option;
