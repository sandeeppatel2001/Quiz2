import { useState } from "react";
import "./App.css";
import Categorize from "./components/Categories";
import Comprehension from "./components/Comprehension";
import FillBlanks from "./components/FillBlanks";
import { useSelector } from "react-redux";
import store from "./store";
function App() {
  const flist = useSelector((state) => state);
  const data1 = flist.counter.count;
  const data2 = flist.counter2.count;
  const data3 = flist.counter3.count1;

  const preview = () => {
    console.log("from App.js   DDDDDDDDDDDD", flist.counter.formlist);
  };
  return (
    <div className="App">
      {/* <Categorize /> */}
      {/* <FillBlanks /> */}
      {/* <Comprehension /> */}
      {data1.map((v, i) => {
        return <Categorize name="sandeep" no={i} />;
      })}
      {data2.map((v, i) => {
        return <FillBlanks no={i} />;
      })}
      {data3.map((v, i) => {
        return <Comprehension no={i} />;
      })}
      <button onClick={preview}>Preview</button>
    </div>
  );
}

export default App;
