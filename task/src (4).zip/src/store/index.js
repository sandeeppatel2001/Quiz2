import { createSlice, configureStore } from "@reduxjs/toolkit";
const intialstate = {
  formlist: [],
  count: [1],
};
const dataslice = createSlice({
  name: "cat",
  initialState: {
    formlist: [],
    count: [1],
  },

  reducers: {
    adddata(state, action) {
      const key = action.payload.key;
      console.log("actionhhhhhhhhhhhhhhhhhhhh", action.payload);
      if (key < state.formlist.length)
        state.formlist[action.payload.key] = action.payload;
      else state.formlist.push(action.payload);
    },
    addnewquestion(state) {
      console.log("pushed successfull");
      state.count.push(1);
    },
  },
});
const dataslice3 = createSlice({
  name: "com",
  initialState: {
    question: [],
    options: [],
    selectedoptions: [],
    oquestion: [],
    count1: [1],
    count2: [[1]],
  },

  reducers: {
    adddata(state, action) {
      const key = action.payload.key;
      console.log("actionhhhhhhhhhhhhhhhhhhhh", action.payload);
      // if (key < state.formlist.size())
      //   state.formlist[action.payload.key] = action.payload;
      // else state.formlist.push(action.payload);
      state.formlist[key] = action.payload;
    },
    addnewquestion(state) {
      console.log("pushed successfull");
      state.count1.push(1);
      state.count2.push([1]);
    },
    addnewquestion2(state, action) {
      console.log("pushed successfull", action.payload);
      state.count2[action.payload].push(1);
    },
    addoption(state, action) {
      const key1 = action.payload.key1;
      const key2 = action.payload.key2;
      const key3 = action.payload.key3;
      console.log("actionhhhhhhhhhhhhhhhhhhhh", action.payload);
      // state.options[key] = action.payload;
      if (state.options[key1] == null) {
        let y = [];
        y[key2] = {
          [key3]: action.payload.data,
        };
        state.options[key1] = y;
      } else {
        if (state.options[key1][key2] == null) {
          state.options[key1][key2] = {
            [key3]: action.payload.data,
          };
        } else {
          state.options[key1][key2] = {
            ...state.options[key1][key2],
            [key3]: action.payload.data,
          };
        }
      }
      // if (key < state.formlist.size())
      //   state.formlist[action.payload.key] = action.payload;
      // else state.formlist.push(action.payload);
    },
    addquestion(state, action) {
      const key = action.payload.key;
      console.log("actionhhhhhhhhhhhhhhhhhhhh", action.payload);
      state.question[key] = action.payload.q;
      // if (key < state.formlist.size())
      //   state.formlist[action.payload.key] = action.payload;
      // else state.formlist.push(action.payload);
    },
    addselectedoptions(state, action) {
      const key1 = action.payload.key1;
      const key2 = action.payload.key2;
      console.log("actionhhhhhhhhhhhhhhhhhhhh", action.payload);

      if (state.selectedoptions[key1] == null) {
        let y = [];
        y[key2] = action.payload.data;
        state.selectedoptions[key1] = y;
      } else {
        state.selectedoptions[key1][key2] = action.payload.data;
      }
    },
    addoquestion(state, action) {
      const key1 = action.payload.key1;
      const key2 = action.payload.key2;
      console.log("actionhhhhhhhhhhhhhhhhhhhh", action.payload);

      if (state.oquestion[key1] == null) {
        let y = [];
        y[key2] = action.payload.data;
        state.oquestion[key1] = y;
      } else {
        state.oquestion[key1][key2] = action.payload.data;
      }
    },
  },
});
const dataslice2 = createSlice({
  name: "fill",
  initialState: {
    formlist: [],
    count: [1],
  },

  reducers: {
    adddata(state, action) {
      const key = action.payload.key;
      console.log("actionhhhhhhhhhhhhhhhhhhhh", action.payload);
      state.formlist[key] = action.payload;
      // if (key < state.formlist.size())
      //   state.formlist[action.payload.key] = action.payload;
      // else state.formlist.push(action.payload);
    },

    addnewquestion(state) {
      console.log("pushed successfull");
      state.count.push(1);
    },
  },
});
const store = configureStore({
  reducer: {
    counter: dataslice.reducer,
    counter2: dataslice2.reducer,
    counter3: dataslice3.reducer,
  },
});
export const savedataaction = dataslice.actions;
export const savedataaction2 = dataslice2.actions;
export const savedataaction3 = dataslice3.actions;
export default store;
