import React from "react";

const Question2Box = (props) => {
  return (
    <div style={{ display: "flex" }}>
      {props.data.map((v, i) => {
        return <div className="question2__box">{v}</div>;
      })}
      {/* <div className="question2__box">Option</div>;
      <div className="question2__box">Option</div>; */}
    </div>
  );
};

export default Question2Box;
