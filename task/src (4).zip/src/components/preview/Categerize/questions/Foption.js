const Foptions = (props) => {
  //   char one = "1";
  console.log("fffff", props.data["1"]);
  return (
    <div className="passege_option">
      <div className="question__item mt-2 mb-3">
        <div className="heading ps-3 w-100">Question 3.1</div>
        <div className="bar mt-2"></div>
        <div className="ms-4 ps-3 mt-3 w-100">
          <h6>{props.q}</h6>
          <div className="mb-1">
            <input type="radio" name="a" className="me-1" />
            <label>{props.data["1"]}</label>
          </div>
          <div className="mb-1">
            <input type="radio" name="a" className="me-1" />
            <label>{props.data["2"]}</label>
          </div>
          <div className="mb-1">
            <input type="radio" name="a" className="me-1" />
            <label>{props.data["3"]}</label>
          </div>
          <div className="mb-1">
            <input type="radio" name="a" className="me-1" />
            <label>{props.data["4"]}</label>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Foptions;
