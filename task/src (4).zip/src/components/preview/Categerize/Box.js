import "../Preview.css";

const Box = (props) => {
  return (
    <div key={props.no} className="boxandname">
      <div className="boxname">{props.data}</div>
      <div className="box"></div>
    </div>
  );
};
export default Box;
