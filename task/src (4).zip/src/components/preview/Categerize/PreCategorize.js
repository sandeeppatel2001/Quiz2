import Box from "./Box";

const PreCategorize = (props) => {
  function dragover(ev) {
    console.log("dragover");
    ev.preventDefault();
  }
  // console.log("ddddddd", props.data.items);
  function drag(ev) {
    console.log("drag start");
    ev.dataTransfer.setData("text", ev.target.id);
  }
  function drop(ev) {
    console.log("droped", ev);
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
  }
  return (
    <div className="cat">
      <div className="words">
        {props.data.items.map((v, i) => {
          if (v === "") return;
          return (
            <p id="drag1" draggable="true" onDragStart={drag} className="word">
              {v}
            </p>
          );
        })}
      </div>
      <div className="boxcollection">
        {props.data.cat.map((v, i) => {
          if (v === "") return;
          return (
            <Box onDrop={drop} onDragOver={dragover} data={v} no={i}></Box>
          );
        })}
        {/* <Box onDrop={drop} onDragOver={dragover} no={1}></Box>{" "}
        
        <Box no={2}></Box> */}
      </div>
    </div>
  );
};
export default PreCategorize;
