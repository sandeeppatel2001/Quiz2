import React from 'react'

const SelectForJump = () => {
  return (
    <div className='select_for_jump'>1</div>
  )
}

export default SelectForJump;