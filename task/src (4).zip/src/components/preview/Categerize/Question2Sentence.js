import React from "react";

export const Question2Sentence = (props) => {
  return <div className="mt-5">{props.data}</div>;
};
