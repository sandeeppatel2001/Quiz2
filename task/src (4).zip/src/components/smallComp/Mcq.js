import Option from "./Option";
import { savedataaction3 } from "../../store";
import { useDispatch, useSelector } from "react-redux";
import { useState } from "react";
const Mcq = (props) => {
  console.log("wwwww", props.index + " " + props.name);
  // const data = useSelector((state) => state);
  // const data3 = data.counter.formlist;
  const dispatch = useDispatch();
  // const [selectedOption, setSelectedOption] = useState(null);
  const addin2 = () => {
    dispatch(savedataaction3.addnewquestion2(props.index));
  };
  const oquestionhandler = (e) => {
    dispatch(
      savedataaction3.addoquestion({
        key1: props.index,
        key2: props.name,
        data: e.target.value,
      })
    );
  };
  const handleOptionChange = (optionValue) => {
    // Update the state when a radio button is selected
    // setSelectedOption(optionValue);
    // let t = data3.selected;
    // t[props.index] = optionValue;
    dispatch(
      savedataaction3.addselectedoptions({
        key1: props.index,
        key2: props.name,
        data: optionValue,
      })
    );
  };
  return (
    <div className="ms-4 mt-3 ">
      <div>
        <p6> Question here:</p6>
        <input onChange={oquestionhandler}></input>
      </div>
      <div className="mb-1">
        <input
          onChange={() => handleOptionChange(1)}
          type="radio"
          name={props.index + " " + props.name}
          className="me-1"
        />
        <label>
          {<Option key1={props.index} key2={props.name} key3={1}></Option>}
        </label>
      </div>
      <div className="mb-1">
        <input
          onChange={() => handleOptionChange(2)}
          type="radio"
          name={props.index + " " + props.name}
          className="me-1"
        />
        <label>
          {<Option key1={props.index} key2={props.name} key3={2}></Option>}
        </label>
      </div>
      <div className="mb-1">
        <input
          onChange={() => handleOptionChange(3)}
          type="radio"
          name={props.index + " " + props.name}
          className="me-1"
        />
        <label>
          {<Option key1={props.index} key2={props.name} key3={3}></Option>}
        </label>
      </div>
      <div className="mb-1">
        <input
          onChange={() => handleOptionChange(4)}
          type="radio"
          name={props.index + " " + props.name}
          className="me-1"
        />
        <label>
          {<Option key1={props.index} key2={props.name} key3={4}></Option>}
        </label>
      </div>
      <button onClick={addin2}>+</button>
    </div>
  );
};

export default Mcq;
